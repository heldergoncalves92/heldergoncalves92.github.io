<?php
	
	$expirationTime = 5000;
	
	setcookie('visit', 'yes', time() + ($expirationTime), "/");

	
		$servername = "localhost";
		$username = "u123942487_admin";
		$password = "password";
		$dbname = "u123942487_helgo";

		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);

		// Check connection
		if ($conn->connect_error) {
    			die("Connection failed: " . $conn->connect_error);
		} 
		
		
		$sql = "SELECT SUM(VISITS) FROM HISTORY";
		$result = $conn->query($sql);
		$row=mysqli_fetch_row($result);
		
		echo "Numero de Visitas " . $row[0];

?>