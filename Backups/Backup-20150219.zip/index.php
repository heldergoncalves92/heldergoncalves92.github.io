<?php include 'counter.php';?>
<!DOCTYPE html>
<html lang="en">
	<head>

		<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css"/>
		<link rel="stylesheet" href="css/charts.css"/>
		<link rel="stylesheet" href="css/main.css"/>
		
		<meta charset='utf8'/>
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"/>
		<meta name='author' content='Hélder José Alves Gonçalves'/>
		<meta name='keywords' contend='Hélder,Gonçalves,developer,software,informatics,webpage,personal,lei,minho,braga,barcelos'>
		<meta name='description' name="Hello, I'm Hélder Gonçalves! The desire to know more about computers woke early. In the beginning, I played games, then got to take a course of Microsoft Office. May not be a big deal, but I was fascinated. Over time, the desire to know more was increasing and when I got to the High School, I already knew what I would choose in College. Actualy, I'm MSc Informatics Engineering at University of Minho.">
		<title>Hélder Gonçalves</title>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-51792409-2', 'auto');
  ga('send', 'pageview');

</script>

	</head>	
	<body>

		<nav id='nav-main' class='navbar navbar-default navbar-fixed-top'>
			<div class="container-fluid">
		    <!-- Brand and toggle get grouped for better mobile display -->
		    	<div class="navbar-header">
		     		<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
		        		<span class="sr-only">Toggle navigation</span>
		        		<span class="icon-bar"></span>
		        		<span class="icon-bar"></span>
		        		<span class="icon-bar"></span>
		      		</button>
		    		<!--  <a class="navbar-brand" href="#">Brand</a>-->
		    	</div>

		    	<!-- Collect the nav links, forms, and other content for toggling -->
		    	<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		        	<ul class="nav navbar-nav navbar-right">
			      		<li><a onclick='scrollToElem(body)'>Home</a></li>
						<li><a onclick='scrollToElem(about)'>About</a></li>
						<li><a onclick='scrollToElem(portfolio)'>Portfolio</a></li>
						<li><a onclick='scrollToElem(contact)'>Contact</a></li>
		      		</ul>
		    	</div><!-- /.navbar-collapse -->
		  	</div><!-- /.container-fluid -->
		</nav>

		<section id="carousel-example-generic" class="carousel slide" data-ride="carousel">
		  	<!-- Indicators -->
		  	<ol class="carousel-indicators">
		    	<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
		    	<li data-target="#carousel-example-generic" data-slide-to="1" ></li>
		    	
		  	</ol>

		  	<!-- Wrapper for slides -->
		  	<div class="carousel-inner" role="listbox">
		    	<div class="item active">
		      		<div class="carousel-caption">
		        		<h1>If we <strong>THINK</strong> beyond the limits, the possibilities are <strong>ENDLESS</strong></h1>
		      		</div>
		      		<img src="img/horizontes.jpg" alt="" align='middle'>
		    	</div>

		    	<div class="item">
		      		<img src="img/do-today.jpg" alt="" align='middle'>
		      		<div class="carousel-caption">
		        	  <h1></h1>

		      		</div>
		    	</div>
		    	
		  	</div>

		  	<!-- Controls -->
		  	<a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
		    	<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
		    	<span class="sr-only">Previous</span>
		  	</a>
		  	<a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
		    	<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
		    	<span class="sr-only">Next</span>
		  	</a>
		</section>	

		<section id='main-contend'>

			<section id='about' class='container text-center'>

				<h1 class='title '>About</h1>
				<hr class='break'\>

				<div class='row'>
					<div class='col-xs-12 col-sm-offset-1 col-sm-10 col-md-offset-0 col-md-7'>
						<p>Hello, I'm <strong>Hélder Gonçalves</strong>!</p>
						<p>The desire to know more about computers woke early. In the beginning, I played games,  then got to take a course of  Microsoft Office. May not be a big deal, but I was fascinated. Over time, the desire to know more was increasing and when I got to the High School, I already knew what I would choose in College.</p>
						<p>Actualy, I'm MSc Informatics Engineering at <em>University of Minho</em>.</p>
	
					</div>
					<div class='col-xs-12 col-sm-offset-1 col-sm-10  col-md-offset-0 col-md-5'>

						<img src="img/profile.jpg" alt="profile" class="img-thumbnail">
					</div>
				</div>
			</section>

			<div class="parallax-window" data-parallax="scroll" data-image-src="img/sky-wall.jpg">
				<section id='skills' class='container text-center'>
					<h1 class='title2'>Key Skills</h1>
					<hr class='break2'\>
					<div class='row' >
						<div id='div1' class='skill col-xs-offset-1 col-xs-5 col-sm-offset-0 col-sm-3 col-md-offset-1 col-md-2 '></div>
						<div id='div2' class='skill col-xs-offset-0 col-xs-5 col-sm-offset-0 col-sm-3 col-md-offset-0 col-md-2'></div>
						
						<div id='div3' class='skill col-xs-offset-1 col-xs-5 col-sm-offset-0 col-sm-3 col-md-offset-0 col-md-2'></div>
						

						<div id='div4' class='skill col-xs-offset-0 col-xs-5 col-sm-offset-0 col-sm-3 col-md-offset-0 col-md-2'></div>
						<div id='div5' class='skill col-xs-offset-1 col-xs-5 col-sm-offset-0 col-sm-3 col-md-offset-0 col-md-2'></div>
						<div id='div6' class='skill col-xs-offset-0 col-xs-5 col-sm-offset-0 col-sm-3 col-md-offset-4 col-md-2'></div>
						<div id='div7' class='skill col-xs-offset-1 col-xs-5 col-sm-offset-0 col-sm-3 col-md-offset-0 col-md-2'></div>
					</div>
				</section>
			</div>

			<section id='portfolio' class='container text-center'>
				<h1 class='title'>Portfolio</h1>
				<hr class='break'>
				<img width='100%' src="img/coming_soon.png">
			</section>

			<div class="parallax-window" data-parallax="scroll" data-image-src="img/creative.jpg">
				<h1 class='description'>Be <strong><em>CREATIVE</em></strong>!!</h1>
			</div>
		
			<section id='contact' class='container text-center'>
				<h1 class='title'>Contact Me</h1>
				<hr class='break'>
				<div class='row'>
					<div class='col-xs-offset-1 col-xs-10 col-md-offset-0 col-md-6'>
						<img src="img/correio.gif">
						<h3>Be free to say Hello!!</h3>
					</div>
					<div id='message' class='col-xs-offset-1 col-xs-10 col-md-offset-0 col-md-6'>
						<form id='form-message'class='form-horizontal message'>
							<div id='fUser' class="form-group">
							    <div class="col-xs-12 col-sm-offset-1 col-sm-10">
							    	<div class="input-group">
							    		<span class="input-group-addon">
							    			<span class="glyphicon glyphicon-user" aria-hidden="true"></span>
							    		</span>
							      		<input type="text" class="form-control" id="inputUser" placeholder="Your Name (Ex: First Last)">
							      	</div>
							    </div>
							</div>
							<div id='fMail' class="form-group">
							    <div class="col-xs-12 col-sm-offset-1 col-sm-10">
							    	<div class="input-group ">
							    		<span class="input-group-addon"> @ </span>
							    		<input type="email" class="form-control" id="inputMail" placeholder="Your E-mail">
							    	</div>
							    </div>
							</div>
							<div id='fMessage' class="form-group">
							    <div class="col-xs-12 col-sm-offset-1 col-sm-10">
							    	<textarea id="inputMessage" class="form-control" rows="7" placeholder='Your Message'></textarea>
							    </div>
							</div>
							<div class="form-group">
							    <div class="col-xs-12 col-sm-offset-1 col-sm-1">
							      	<div id='btn_send' class="btn btn-primary" onclick='sentMessage()' disabled>
							      		<span class="glyphicon glyphicon-send" aria-hidden="true"></span>
							      		 Send Message
							      	</div>
							    </div>
							</div>
							<div id='msg-alert' class="alert alert-danger" role="alert">Your message was <strong>not sent</strong> successfully. <strong>Try again!</strong></div>
						</form>
						<div id='message-sent'>
							<h3>Message Sent. <strong>Thank You!</strong></h3>
							<img width='100%' src="img/sent_successful.png">
						</div>
					</div>
				</div><!--Close RowMessage-->
			</section>	
		</section>

		<footer>
			<div  class='container-fluid text-center'>
				<h1>Let's Be Friends</h1>
				<div class='row'>
					<a href="https://www.facebook.com/helderjosegoncalves" target='_blank'><img id='facebook' width='100%' src="img/icon/facebook_gray.png"></a>
					<a href="https://twitter.com/heldergon92" target='_blank'><img id='twitter' width='100%' src="img/icon/twitter_gray.png"></a>
					<a href="https://www.linkedin.com/pub/h%C3%A9lder-gon%C3%A7alves/83/626/7b" target='_blank'><img id='linkedin' width='100%' src="img/icon/linkedin_gray.png"></a>
					<a href="https://github.com/HelderGoncalves92" target='_blank'><img id='github' width='100%' src="img/icon/github_gray.png"></a>
				</div>
			</div>
			<div id='credits'>
				<p class='right'>Developed by: <strong>Hélder Gonçalves</strong></p>
				<p>© Copyright 2015</p>
			</div>
		</footer>
		<script src='js/jquery-1.11.min.js'></script>		
		<script src="js/d3.min.js"></script>
    	<script src="js/radialProgress.js"></script>

		<script src='js/parallax.min.js'></script>
		<script src='bootstrap/js/bootstrap.min.js'></script>
		<script src='js/main.js'></script>
	</body>
</html>