<?php
	
	$expirationTime = 7000;
	
	setcookie('visit', 'yes', time() + ($expirationTime), "/");
	
	if(!isset($_COOKIE['visit'])) {
		$servername = "localhost";
		$username = "u123942487_admin";
		$password = "password";
		$dbname = "u123942487_helgo";

		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);

		// Check connection
		if ($conn->connect_error) {
    			die("Connection failed: " . $conn->connect_error);
		} 
		
		//Test IP
		$ip = $_SERVER['REMOTE_ADDR'];
		$sql = "SELECT * FROM SESSIONS WHERE REMOTE_ADD='$ip'";
		$result = $conn->query($sql);
		$row=mysqli_fetch_row($result);

		if($row){
			$time = time();
			$diff = $time - $row[1];

			if($diff > $expirationTime){
			//	echo 'Actualiza!!';
				$sql = "UPDATE SESSIONS SET LAST_ACCESS = $time WHERE REMOTE_ADD='$ip'";
				$conn->query($sql);

				$today = date("d m y");
				sscanf($today, "%d %d %d", $day, $month, $year);

				$sql="SELECT VISITS FROM HISTORY WHERE DAY=$day AND MONTH=$month AND YEAR=$year";
				$result = $conn->query($sql);
				$row=mysqli_fetch_row($result);

				if(!$row){
					$sql="INSERT INTO HISTORY VALUES ($day, $month, $year, 1)";
					$conn->query($sql);
				
				}else{
					$sql="UPDATE HISTORY SET VISITS=VISITS +1 WHERE DAY=$day AND MONTH=$month AND YEAR=$year";
					$conn->query($sql);
				}
			}
			
		}else{
			//echo "Sem IP!!";
			$time = time();
			$sql = "INSERT INTO SESSIONS VALUES ('$ip', $time)";
			$conn->query($sql);

			$today = date("d m y");
			sscanf($today, "%d %d %d", $day, $month, $year);

			$sql="SELECT VISITS FROM HISTORY WHERE DAY=$day AND MONTH=$month AND YEAR=$year";
			$result = $conn->query($sql);
			$row=mysqli_fetch_row($result);

			if(!$row){
				$sql="INSERT INTO HISTORY VALUES ($day, $month, $year, 1)";
				$conn->query($sql);
			
			}else{
				$sql="UPDATE HISTORY SET VISITS=VISITS +1 WHERE DAY=$day AND MONTH=$month AND YEAR=$year";
				$conn->query($sql);
			}
		}

		$conn->close();
	}
?>